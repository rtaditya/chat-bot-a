# ADITYA - Binance Futures Order Bot (Simulated)

## Overview
CLI-based simulated bot supporting Market, Limit, Stop-Limit, OCO, TWAP, and Grid orders.
This is a safe, non-live scaffold for educational/submission purposes.

## Setup
```bash
python -m venv .venv
# activate environment:
# Windows (PowerShell):
.venv\Scripts\Activate.ps1
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

## Usage (examples)
```bash
# Market order
python app.py market --symbol BTCUSDT --side BUY --quantity 0.01

# Limit order
python app.py limit --symbol ETHUSDT --side SELL --quantity 0.05 --price 1850

# Stop-limit
python app.py stop-limit --symbol BTCUSDT --side BUY --quantity 0.01 --stop 30000 --limit 29950

# OCO
python app.py oco --symbol BTCUSDT --side BUY --quantity 0.01 --tp 35000 --sl 32000

# TWAP
python app.py twap --symbol BTCUSDT --side BUY --quantity 0.06 --intervals 3 --delay 1

# Grid
python app.py grid --symbol BTCUSDT --side BUY --low 28000 --high 32000 --steps 5 --qty 0.01
```

## Logs
All actions are logged to `bot.log` in the project root.

## Notes
- This project **does not** place real orders. Replace simulated implementations with a proper SDK and handle API keys securely to enable live trading.
