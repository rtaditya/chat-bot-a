from .utils import setup_logging, OrderModel
import logging
setup_logging()
logger = logging.getLogger(__name__)

def place_market_order(symbol: str, side: str, quantity: float):
    payload = {"symbol": symbol, "side": side, "type": "MARKET", "quantity": quantity}
    order = OrderModel(**payload)
    logger.info(f"Placing MARKET order: {side} {quantity} {order.symbol}")
    # Simulated response
    resp = {"orderId": int(time_now_ms()), "status": "FILLED", "filledQty": quantity, "symbol": order.symbol, "side": side, "type": "MARKET"}
    logger.info("Order result: %s", resp)
    return resp

def time_now_ms():
    import time
    return int(time.time() * 1000)
