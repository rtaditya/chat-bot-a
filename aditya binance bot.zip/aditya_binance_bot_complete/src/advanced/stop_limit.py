from ..utils import setup_logging, OrderModel
import logging, time
setup_logging()
logger = logging.getLogger(__name__)

# Simulated stop-limit: poll a fake price feed (here we just simulate trigger after delay)
def place_stop_limit(symbol: str, side: str, quantity: float, stop_price: float, limit_price: float, wait_seconds: int = 2):
    payload = {"symbol": symbol, "side": side, "type": "STOP_LIMIT", "quantity": quantity, "stop_price": stop_price, "price": limit_price}
    order = OrderModel(**payload)
    logger.info(f"Placing STOP-LIMIT: {side} {quantity} {symbol} stop={stop_price} limit={limit_price}")
    # Simulate waiting for stop to hit
    logger.info('Simulating market monitoring...')
    time.sleep(wait_seconds)
    # When triggered, place a limit order (simulate immediate placement)
    from ..limit_orders import place_limit_order
    resp = place_limit_order(symbol, side, quantity, limit_price)
    logger.info('Stop-limit triggered and limit order placed: %s', resp)
    return {"triggered": True, "placed": resp}
