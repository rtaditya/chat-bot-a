from ..utils import setup_logging, OrderModel
import logging, time
setup_logging()
logger = logging.getLogger(__name__)

def create_grid(symbol: str, side: str, low: float, high: float, steps: int, qty_per_order: float, delay: float = 0.5):
    logger.info(f'Creating grid for {symbol} between {low}-{high} in {steps} steps, qty/order={qty_per_order}')
    step_size = (high - low) / max(1, steps-1)
    orders = []
    from ..limit_orders import place_limit_order
    price = low
    for i in range(steps):
        logger.info(f'Placing grid limit at {price}')
        ord = place_limit_order(symbol, side, qty_per_order, price)
        orders.append(ord)
        price += step_size
        time.sleep(delay)
    logger.info('Grid created with %d orders', len(orders))
    return {"status": "CREATED", "orders": orders}
