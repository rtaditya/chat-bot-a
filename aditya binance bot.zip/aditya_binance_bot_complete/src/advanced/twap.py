from ..utils import setup_logging, OrderModel
import logging, time
setup_logging()
logger = logging.getLogger(__name__)

def execute_twap(symbol: str, side: str, total_qty: float, intervals: int, delay: float):
    logger.info(f'Executing TWAP {side} {total_qty} {symbol} over {intervals} intervals, delay={delay}s')
    chunk = total_qty / intervals
    results = []
    from ..market_orders import place_market_order
    for i in range(intervals):
        logger.info(f'TWAP chunk {i+1}/{intervals}: {chunk} {symbol}')
        res = place_market_order(symbol, side, chunk)
        results.append(res)
        time.sleep(delay)
    return {"status": "COMPLETED", "executions": results}
