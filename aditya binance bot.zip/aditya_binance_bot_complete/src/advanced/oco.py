from ..utils import setup_logging, OrderModel
import logging
setup_logging()
logger = logging.getLogger(__name__)

# Simulated OCO: place TP (limit) and SL (stop-limit) and return both order ids
def place_oco_order(symbol: str, side: str, quantity: float, take_profit: float, stop_loss: float):
    logger.info(f'Placing simulated OCO for {symbol} qty={quantity} TP={take_profit} SL={stop_loss}')
    # Simulate placing two child orders
    from ..limit_orders import place_limit_order
    from .stop_limit import place_stop_limit
    tp = place_limit_order(symbol, 'SELL' if side=='BUY' else 'BUY', quantity, take_profit)
    sl = place_stop_limit(symbol, 'SELL' if side=='BUY' else 'BUY', quantity, stop_loss, stop_loss, wait_seconds=0)
    logger.info('OCO placed: TP=%s SL=%s', tp, sl)
    return {"take_profit": tp, "stop_loss": sl}
