from .utils import setup_logging, OrderModel
import logging
setup_logging()
logger = logging.getLogger(__name__)

def place_limit_order(symbol: str, side: str, quantity: float, price: float):
    payload = {"symbol": symbol, "side": side, "type": "LIMIT", "quantity": quantity, "price": price}
    order = OrderModel(**payload)
    logger.info(f"Placing LIMIT order: {side} {quantity} {order.symbol} @ {price}")
    # Simulated response (placed, not filled)
    resp = {"orderId": int(time_now_ms()), "status": "NEW", "price": price, "symbol": order.symbol, "side": side, "type": "LIMIT"}
    logger.info("Order result: %s", resp)
    return resp

def time_now_ms():
    import time
    return int(time.time() * 1000)
