import logging, os
from pydantic import BaseModel, validator, root_validator
from typing import Optional

LOG_FILE = os.path.join(os.getcwd(), 'bot.log')

def setup_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    # Prevent duplicate handlers
    if not any(isinstance(h, logging.FileHandler) and getattr(h, 'baseFilename', '') == LOG_FILE for h in logger.handlers):
        fh = logging.FileHandler(LOG_FILE)
        fmt = logging.Formatter('%(asctime)s %(levelname)s %(name)s - %(message)s')
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    # also console handler
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        ch = logging.StreamHandler()
        ch.setFormatter(logging.Formatter('%(levelname)s - %(message)s'))
        logger.addHandler(ch)

class OrderModel(BaseModel):
    symbol: str
    side: str
    type: str
    quantity: float
    price: Optional[float] = None
    stop_price: Optional[float] = None

    @validator('symbol')
    def upper_symbol(cls, v):
        v2 = v.upper()
        if not v2.isalnum():
            raise ValueError('symbol must be alphanumeric, e.g. BTCUSDT')
        return v2

    @validator('side')
    def side_check(cls, v):
        if v not in ('BUY', 'SELL'):
            raise ValueError('side must be BUY or SELL')
        return v

    @validator('quantity')
    def qty_positive(cls, v):
        if v <= 0:
            raise ValueError('quantity must be > 0')
        return v

    @root_validator
    def price_checks(cls, values):
        t = values.get('type')
        price = values.get('price')
        stop = values.get('stop_price')
        if t == 'LIMIT' and (price is None or price <= 0):
            raise ValueError('LIMIT orders require a positive price')
        if t == 'STOP_LIMIT' and (stop is None or stop <= 0 or price is None or price <= 0):
            raise ValueError('STOP_LIMIT requires stop_price and price both > 0')
        return values
