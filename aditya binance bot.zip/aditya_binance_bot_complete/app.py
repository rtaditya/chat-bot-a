# CLI launcher for the simulated Binance Futures Order Bot
import click, logging, sys
from src.utils import setup_logging
setup_logging()
logger = logging.getLogger(__name__)

@click.group()
def cli():
    pass

@cli.command()
@click.option('--symbol', required=True)
@click.option('--side', required=True, type=click.Choice(['BUY','SELL']))
@click.option('--quantity', required=True, type=float)
def market(symbol, side, quantity):
    from src.market_orders import place_market_order
    res = place_market_order(symbol, side, quantity)
    click.echo(res)

@cli.command()
@click.option('--symbol', required=True)
@click.option('--side', required=True, type=click.Choice(['BUY','SELL']))
@click.option('--quantity', required=True, type=float)
@click.option('--price', required=True, type=float)
def limit(symbol, side, quantity, price):
    from src.limit_orders import place_limit_order
    res = place_limit_order(symbol, side, quantity, price)
    click.echo(res)

@cli.command()
@click.option('--symbol', required=True)
@click.option('--side', required=True, type=click.Choice(['BUY','SELL']))
@click.option('--quantity', required=True, type=float)
@click.option('--stop', 'stop_price', required=True, type=float)
@click.option('--limit', 'limit_price', required=True, type=float)
def stop_limit(symbol, side, quantity, stop_price, limit_price):
    from src.advanced.stop_limit import place_stop_limit
    res = place_stop_limit(symbol, side, quantity, stop_price, limit_price)
    click.echo(res)

@cli.command()
@click.option('--symbol', required=True)
@click.option('--side', required=True, type=click.Choice(['BUY','SELL']))
@click.option('--quantity', required=True, type=float)
@click.option('--tp', 'take_profit', required=True, type=float)
@click.option('--sl', 'stop_loss', required=True, type=float)
def oco(symbol, side, quantity, take_profit, stop_loss):
    from src.advanced.oco import place_oco_order
    res = place_oco_order(symbol, side, quantity, take_profit, stop_loss)
    click.echo(res)

@cli.command()
@click.option('--symbol', required=True)
@click.option('--side', required=True, type=click.Choice(['BUY','SELL']))
@click.option('--quantity', required=True, type=float)
@click.option('--intervals', required=True, type=int)
@click.option('--delay', required=False, type=float, default=1.0)
def twap(symbol, side, quantity, intervals, delay):
    from src.advanced.twap import execute_twap
    res = execute_twap(symbol, side, quantity, intervals, delay)
    click.echo(res)

@cli.command()
@click.option('--symbol', required=True)
@click.option('--side', required=True, type=click.Choice(['BUY','SELL']))
@click.option('--low', required=True, type=float)
@click.option('--high', required=True, type=float)
@click.option('--steps', required=True, type=int)
@click.option('--qty', 'qty_per', required=True, type=float)
def grid(symbol, side, low, high, steps, qty_per):
    from src.advanced.grid import create_grid
    res = create_grid(symbol, side, low, high, steps, qty_per)
    click.echo(res)

if __name__ == '__main__':
    cli()
